import React, { useState, useEffect } from "react";
import axios from "axios";

const API_URL = "https://family-api-xxxxxx.a.run.app";  // Replace with your deployed API
const API_KEY = "demo_pro_key";                         // Replace with your real API key

export default function FamilyModule() {
  const [points, setPoints] = useState(0);
  const [activities, setActivities] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    axios.get(`${API_URL}/points/points_balance`, {
      headers: { "X-API-Key": API_KEY }
    }).then(res => setPoints(res.data.points));
  }, []);

  const loadActivities = async () => {
    setLoading(true);
    try {
      const res = await axios.get(`${API_URL}/recommend?state=CA&limit=5`, {
        headers: { "X-API-Key": API_KEY }
      });
      setActivities(res.data);
    } catch (err) {
      console.error("Error loading activities", err);
    }
    setLoading(false);
  };

  const upgradeToPro = async () => {
    try {
      const res = await axios.post(`${API_URL}/payments/create-checkout-session`);
      window.location.href = res.data.checkout_url;
    } catch (err) {
      alert("Error creating checkout session: " + err.message);
    }
  };

  return (
    <div style={{ border: "2px solid #eee", padding: "20px", borderRadius: "12px", maxWidth: "600px", margin: "auto", background: "#fafafa" }}>
      <h2>🎯 ScoutFox Family Dashboard</h2>
      <p><strong>Points Balance:</strong> {points}</p>

      <button onClick={loadActivities} style={{ margin: "10px 0", padding: "10px" }}>
        {loading ? "Loading..." : "Find Family Activities"}
      </button>

      <ul>
        {activities.map((a, i) => (
          <li key={i}>
            <strong>{a.name}</strong> ({a.type || "activity"}) – {a.state || "N/A"}
          </li>
        ))}
      </ul>

      <button onClick={upgradeToPro} style={{ background: "gold", padding: "12px", borderRadius: "8px", border: "none", fontWeight: "bold", cursor: "pointer", marginTop: "20px" }}>
        ⭐ Upgrade to Pro
      </button>
    </div>
  );
}
