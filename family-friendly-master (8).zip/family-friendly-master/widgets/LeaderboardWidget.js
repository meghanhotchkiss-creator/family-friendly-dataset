import React, { useState, useEffect } from "react";
import axios from "axios";

const API_URL = "https://family-api-xxxxxx.a.run.app";  // Replace with your API endpoint
const API_KEY = "demo_pro_key";                         // Replace with real API key

export default function LeaderboardWidget() {
  const [leaderboard, setLeaderboard] = useState([]);

  useEffect(() => {
    // Fetch leaderboard from API
    axios.get(`${API_URL}/points/leaderboard`, {
      headers: { "X-API-Key": API_KEY }
    }).then(res => setLeaderboard(res.data));
  }, []);

  return (
    <div style={{ border: "2px solid #eee", padding: "20px", borderRadius: "12px", maxWidth: "600px", margin: "auto", background: "#f0f8ff" }}>
      <h2>🏆 Family Leaderboard</h2>
      <ol>
        {leaderboard.map((entry, i) => (
          <li key={i}>
            <strong>{entry.user}</strong> — {entry.points} pts
          </li>
        ))}
      </ol>
    </div>
  );
}
