# Family Friendly Dataset

This repository maintains a continuously refreshed dataset of family-friendly activities across all 50 US states.

## Features
- Parks, libraries, museums, attractions
- Private businesses (restaurants, indoor play, etc.) via Google Places API
- Auto-refresh via GitHub Actions
- Cloud BigQuery integration

## Usage
- Run scripts in `scripts/` to fetch and merge data.
- The processed dataset is saved in `data/processed/family_friendly_dataset.csv`.
- Use `api/recommender.py` for sample recommendations.
