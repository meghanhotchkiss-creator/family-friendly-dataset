from google.cloud import bigquery
import pandas as pd

BQ_TABLE = "your_project.family_dataset.activities"

def refresh_bigquery(request):
    df = pd.read_csv("data/processed/family_friendly_dataset.csv")

    client = bigquery.Client()
    job = client.load_table_from_dataframe(df, BQ_TABLE)
    job.result()

    return f"BigQuery table {BQ_TABLE} refreshed with {len(df)} rows."
