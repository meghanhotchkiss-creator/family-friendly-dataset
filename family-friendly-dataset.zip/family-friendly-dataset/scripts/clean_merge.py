import pandas as pd
from pathlib import Path

RAW_DIR = Path("data/raw")
PROCESSED_DIR = Path("data/processed")
PROCESSED_DIR.mkdir(parents=True, exist_ok=True)

if __name__ == "__main__":
    libs = pd.read_csv(RAW_DIR / "libraries.csv")
    libs["source"] = "public_libraries"

    # TODO: normalize schema across multiple sources
    merged = libs  # Extend with parks, museums, Google Places data

    merged.to_csv(PROCESSED_DIR / "family_friendly_dataset.csv", index=False)
    print("Dataset refreshed → data/processed/family_friendly_dataset.csv")
