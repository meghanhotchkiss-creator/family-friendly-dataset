import googlemaps

API_KEY = "YOUR_GOOGLE_PLACES_API_KEY"  # Replace with env var in production
gmaps = googlemaps.Client(key=API_KEY)

def fetch_places_in_city(city, state, keywords=["family", "kids"]):
    query = f"family friendly activities in {city}, {state}"
    results = gmaps.places(query=query)
    return results.get("results", [])

if __name__ == "__main__":
    sample = fetch_places_in_city("San Francisco", "CA")
    print(sample)
