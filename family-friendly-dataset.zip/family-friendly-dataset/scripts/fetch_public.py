import requests
import pandas as pd
from pathlib import Path

DATA_DIR = Path("data/raw")
DATA_DIR.mkdir(parents=True, exist_ok=True)

# Example: Fetch US Public Libraries dataset (IMLS)
LIBRARIES_URL = "https://imls.gov/sites/default/files/2023-07/imls_public_libraries.csv"

if __name__ == "__main__":
    print("Fetching public libraries dataset...")
    df = pd.read_csv(LIBRARIES_URL)
    df.to_csv(DATA_DIR / "libraries.csv", index=False)
    print("Saved libraries.csv")
