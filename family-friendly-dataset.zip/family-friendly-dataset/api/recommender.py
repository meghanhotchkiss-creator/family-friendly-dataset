import pandas as pd

DF_PATH = "data/processed/family_friendly_dataset.csv"

def recommend(state: str, indoor=None, limit=10):
    df = pd.read_csv(DF_PATH)
    subset = df[df["STATE"] == state]
    if indoor:
        subset = subset[subset["indoor_or_outdoor"] == indoor]
    return subset.head(limit).to_dict(orient="records")

if __name__ == "__main__":
    results = recommend("CA", indoor="indoor")
    for r in results:
        print(r)
