from fastapi import APIRouter, Depends
from auth_tiers import verify_tier, USER_TIERS

router = APIRouter()

# In-memory points + history store (replace with DB in production)
user_points = {"demo_free_key": 50, "demo_pro_key": 120, "demo_business_key": 500}
user_history = {"demo_free_key": [], "demo_pro_key": [], "demo_business_key": []}

@router.post("/earn_points")
def earn_points(event: str, api_key=Depends(verify_tier("free"))):
    event_points = {
        "daily_checkin": 10,
        "affiliate_booking": 20,
        "upgrade_pro": 50,
        "upgrade_business": 100
    }
    points = event_points.get(event, 0)
    user_points[api_key] = user_points.get(api_key, 0) + points
    user_history.setdefault(api_key, []).append({"event": event, "points": points})
    return {"event": event, "earned": points, "total_points": user_points[api_key]}

@router.get("/points_balance")
def points_balance(api_key=Depends(verify_tier("free"))):
    return {"points": user_points.get(api_key, 0)}

@router.get("/points_history")
def points_history(api_key=Depends(verify_tier("free"))):
    return {"history": user_history.get(api_key, [])}

@router.post("/redeem_points")
def redeem_points(cost: int, api_key=Depends(verify_tier("free"))):
    if user_points.get(api_key, 0) < cost:
        return {"error": "Not enough points"}
    user_points[api_key] -= cost
    user_history.setdefault(api_key, []).append({"event": "redeem", "points": -cost})
    return {"points": user_points[api_key], "message": "Redeemed successfully"}

@router.get("/leaderboard")
def leaderboard(api_key=Depends(verify_tier("free"))):
    entries = []
    for key, pts in user_points.items():
        tier = USER_TIERS.get(key, "free")
        badge = ""
        if tier == "pro":
            badge = "⭐"
        elif tier == "business":
            badge = "👑"
        entries.append({"user": key, "points": pts, "tier": tier, "badge": badge})

    tier_order = {"business": 2, "pro": 1, "free": 0}
    entries.sort(key=lambda x: (x["points"], tier_order[x["tier"]]), reverse=True)
    return entries
